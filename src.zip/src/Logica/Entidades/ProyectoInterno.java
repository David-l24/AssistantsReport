package Logica.Entidades;

public class ProyectoInterno extends Proyecto{
    @Override
    public String getTipoProyecto() {
        return "Interno";
    }
}
