package Logica.Entidades;

public class ProyectoSemilla extends Proyecto{
    @Override
    public String getTipoProyecto() {
        return "Semilla";
    }
}
